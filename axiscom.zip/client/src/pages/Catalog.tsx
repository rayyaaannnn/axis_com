/**
 * Products Catalog Page - Axis Communication
 * 
 * Design: Digital Velocity
 * - Comprehensive catalog of all Jio products
 * - Product cards with images, descriptions, and specifications
 * - Filter and category navigation
 * - Detailed product information
 */

import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Search } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";

interface Product {
  id: string;
  name: string;
  category: string;
  description: string;
  image: string;
  price?: string;
  specs: string[];
  color: string;
}

const products: Product[] = [
  {
    id: "jio-sim",
    name: "Jio SIM",
    category: "Mobile",
    description: "Experience India's fastest 5G network with Jio prepaid and postpaid plans. Get instant activation and multiple plan options.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹99",
    specs: ["5G Ready", "Instant Activation", "Multiple Plans", "Best Rates", "Nationwide Coverage", "24/7 Support"],
    color: "#005AAC",
  },
  {
    id: "jio-fiber",
    name: "JioFiber",
    category: "Broadband",
    description: "High-speed fiber broadband for homes and businesses. Get up to 1Gbps speeds with unlimited data and OTT bundles.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹399/month",
    specs: ["Up to 1Gbps Speed", "Unlimited Data", "OTT Bundle Included", "Free Router", "Installation Support", "24/7 Customer Care"],
    color: "#0080D9",
  },
  {
    id: "jio-airfiber",
    name: "JioAirFiber",
    category: "Broadband",
    description: "5G wireless broadband without any wiring. Plug and play connectivity with affordable plans and no installation hassle.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹599/month",
    specs: ["5G Speed", "No Wiring Required", "Plug & Play", "Affordable Plans", "Portable", "Quick Setup"],
    color: "#00A8FF",
  },
  {
    id: "jio-set-top-box",
    name: "Jio Set-Top Box",
    category: "Entertainment",
    description: "4K Ultra HD entertainment with OTT apps, live TV, voice control, and gaming capabilities. Premium viewing experience.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "Free with JioFiber",
    specs: ["4K Ultra HD", "1000+ OTT Apps", "Voice Control", "Gaming Ready", "Video Calling", "Smart Features"],
    color: "#00D9FF",
  },
  {
    id: "jio-bharat-phone",
    name: "JioBharat Phone",
    category: "Devices",
    description: "Feature-rich 4G phone designed for India. Affordable, reliable, and packed with essential features for everyday use.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹1,299",
    specs: ["4G Connectivity", "Long Battery Life", "Clear Display", "Dual SIM", "Safety Shield", "Affordable"],
    color: "#FF6B35",
  },
  {
    id: "jio-phone",
    name: "JioPhone",
    category: "Devices",
    description: "India's most affordable smartphone with 4G connectivity. Perfect for first-time smartphone users with essential features.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹2,999",
    specs: ["4G LTE", "Touchscreen", "Dual SIM", "Expandable Storage", "Long Battery", "Affordable"],
    color: "#FF8C42",
  },
  {
    id: "jio-smart-speaker",
    name: "Jio Smart Speaker",
    category: "Smart Home",
    description: "Voice-controlled smart speaker with AI assistant. Control your home, play music, and get information hands-free.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹3,999",
    specs: ["Voice Control", "AI Assistant", "Smart Home Control", "Music Streaming", "Weather Updates", "News Briefing"],
    color: "#6C5CE7",
  },
  {
    id: "jio-security-camera",
    name: "Jio Security Camera",
    category: "Smart Home",
    description: "HD security camera for your home. Monitor your property 24/7 with cloud storage and mobile alerts.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹2,999",
    specs: ["HD Resolution", "Night Vision", "Cloud Storage", "Mobile Alerts", "Two-Way Audio", "24/7 Monitoring"],
    color: "#A29BFE",
  },
  {
    id: "jio-router",
    name: "Jio WiFi Router",
    category: "Networking",
    description: "High-performance WiFi router for seamless connectivity. Dual-band technology for faster speeds and better coverage.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "Free with JioFiber",
    specs: ["Dual-Band WiFi", "High Speed", "Wide Coverage", "Easy Setup", "Parental Controls", "Multiple Devices"],
    color: "#74B9FF",
  },
  {
    id: "jio-space-fiber",
    name: "Jio SpaceFiber",
    category: "Broadband",
    description: "Satellite-based broadband for remote areas. High-speed internet connectivity where fiber is not available.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "From ₹799/month",
    specs: ["Satellite Internet", "Remote Coverage", "High Speed", "Reliable Connection", "Professional Installation", "24/7 Support"],
    color: "#00B4DB",
  },
  {
    id: "jio-music",
    name: "Jio Music",
    category: "Entertainment",
    description: "Unlimited music streaming with millions of songs. Ad-free listening with offline downloads and high-quality audio.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "Free with Jio Plans",
    specs: ["Millions of Songs", "Ad-Free", "Offline Download", "High Quality Audio", "Personalized Playlists", "Podcast Support"],
    color: "#FF6B9D",
  },
  {
    id: "jio-tv",
    name: "Jio TV+",
    category: "Entertainment",
    description: "Live TV, movies, and shows on demand. Watch your favorite content anytime, anywhere with premium quality.",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-products-showcase-oYn3dEmpL4L4yztMtpahfU.webp",
    price: "Free with Jio Plans",
    specs: ["Live TV Channels", "Movies On Demand", "Web Series", "Premium Content", "Multi-Device", "Cloud Recording"],
    color: "#C44569",
  },
];

const categories = ["All", "Mobile", "Broadband", "Entertainment", "Devices", "Smart Home", "Networking"];

const PHONE_NUMBER = "+917006285994";
const EMAIL = "axiscommunication@gmail.com";
const WHATSAPP_MESSAGE = "Hi! I'm interested in Jio products. Can you help me?";

export default function Catalog() {
  const [scrolled, setScrolled] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleProducts, setVisibleProducts] = useState<Set<string>>(new Set());
  const [, navigate] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      // Trigger product card animations on scroll
      const cards = document.querySelectorAll("[data-product-card]");
      cards.forEach((card) => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.8) {
          const id = card.getAttribute("data-product-id");
          if (id) {
            setVisibleProducts((prev) => new Set(prev).add(id));
          }
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleWhatsApp = () => {
    const message = encodeURIComponent(WHATSAPP_MESSAGE);
    window.open(`https://wa.me/${PHONE_NUMBER.replace(/\D/g, "")}?text=${message}`, "_blank");
  };

  const handlePhone = () => {
    window.location.href = `tel:${PHONE_NUMBER}`;
  };

  const handleHome = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white/90 backdrop-blur-xl shadow-sm border-b border-border"
            : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <button onClick={handleHome} className="flex items-center gap-3 hover:opacity-80 transition">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-logo-icon-AC6huavmCyooy7Bbp4uJAH.webp"
              alt="Jio Logo"
              className="w-10 h-10"
            />
            <div>
              <span className={`font-display font-bold text-lg block ${scrolled ? "text-foreground" : "text-foreground"}`}>
                Axis Communication
              </span>
              <span className="text-xs text-muted-foreground">Jio Services & Support - J&K</span>
            </div>
          </button>
          <nav className="hidden md:flex gap-8">
            <button onClick={handleHome} className="text-sm font-medium hover:text-primary transition-colors">
              Home
            </button>
            <button onClick={handleHome} className="text-sm font-medium hover:text-primary transition-colors">
              Services
            </button>
            <button className="text-sm font-medium text-primary transition-colors">
              Catalog
            </button>
            <button onClick={handleHome} className="text-sm font-medium hover:text-primary transition-colors">
              Contact
            </button>
          </nav>
          <Button onClick={handleWhatsApp} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            Get Support
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 md:pt-40 md:pb-24 overflow-hidden bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl">
            <h1 className="font-display text-5xl md:text-6xl font-bold mb-4 text-foreground leading-tight">
              Jio Products Catalog
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
              Explore our complete range of Jio products and services. From mobile connectivity to broadband, entertainment to smart home solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="sticky top-24 md:top-20 z-40 bg-white border-b border-border py-6">
        <div className="container mx-auto px-4">
          {/* Search Bar */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-4 py-2 rounded-full font-medium transition-all whitespace-nowrap ${
                  selectedCategory === category
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <Card
                key={product.id}
                data-product-card
                data-product-id={product.id}
                className={`group overflow-hidden transition-all duration-500 hover:shadow-xl hover:-translate-y-2 ${
                  visibleProducts.has(product.id)
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
              >
                {/* Product Image */}
                <div className="relative h-64 overflow-hidden bg-secondary">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div
                    className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-semibold text-white"
                    style={{ backgroundColor: product.color }}
                  >
                    {product.category}
                  </div>
                </div>

                {/* Product Info */}
                <div className="p-6">
                  <h3 className="font-display text-2xl font-bold mb-2 text-foreground">
                    {product.name}
                  </h3>
                  {product.price && (
                    <p className="text-lg font-semibold text-primary mb-3">
                      {product.price}
                    </p>
                  )}
                  <p className="text-muted-foreground mb-6 line-clamp-2">
                    {product.description}
                  </p>

                  {/* Specs */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-sm text-foreground mb-3">Key Features:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {product.specs.slice(0, 4).map((spec, idx) => (
                        <div key={idx} className="flex items-start gap-2">
                          <div
                            className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                            style={{ backgroundColor: product.color }}
                          />
                          <span className="text-xs text-muted-foreground">{spec}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button
                    onClick={handleWhatsApp}
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                  >
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-16">
              <p className="text-lg text-muted-foreground mb-4">
                No products found matching your search.
              </p>
              <Button
                variant="outline"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("All");
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-6">
            Need Help Choosing?
          </h2>
          <p className="text-lg text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            Our expert team is here to help you find the perfect Jio product for your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleWhatsApp}
              size="lg"
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
            >
              Contact Our Team
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button
              onClick={handlePhone}
              size="lg"
              variant="outline"
              className="border-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
            >
              Call Us Now
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-primary-foreground py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-display font-bold mb-4">Axis Communication</h4>
              <p className="text-sm text-primary-foreground/70">
                Your trusted Jio services provider and customer support partner in Srinagar, J&K.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Quick Links</h5>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li><button onClick={handleHome} className="hover:text-primary-foreground transition">Home</button></li>
                <li><button className="hover:text-primary-foreground transition">Catalog</button></li>
                <li><button onClick={handleHome} className="hover:text-primary-foreground transition">Contact</button></li>
                <li><button onClick={handlePhone} className="hover:text-primary-foreground transition">Support</button></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li><button onClick={handlePhone} className="hover:text-primary-foreground transition">Help Center</button></li>
                <li><button onClick={handlePhone} className="hover:text-primary-foreground transition">Contact Us</button></li>
                <li><button className="hover:text-primary-foreground transition">FAQ</button></li>
                <li><button className="hover:text-primary-foreground transition">Service Status</button></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Legal</h5>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li><a href="#" className="hover:text-primary-foreground transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition">Disclaimer</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-primary-foreground/20 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-primary-foreground/70">
            <p>&copy; 2026 Axis Communication. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <button onClick={handleWhatsApp} className="hover:text-primary-foreground transition">WhatsApp</button>
              <button onClick={handlePhone} className="hover:text-primary-foreground transition">Call</button>
              <button onClick={handleHome} className="hover:text-primary-foreground transition">Home</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
