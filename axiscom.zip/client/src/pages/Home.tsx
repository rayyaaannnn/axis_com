/**
 * Home Page - Axis Communication (Jio Customer Support & Services)
 * 
 * Design: Digital Velocity
 * - Hero section with gradient background and dynamic typography
 * - Service showcase section highlighting JioFiber and support
 * - Asymmetric layout with flowing sections
 * - Contact section for customer inquiries
 */

import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Smartphone, Wifi, Radio, Tv, ArrowRight, Zap, MapPin, Mail, Phone, Headphones, Clock, CheckCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";

interface Service {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  features: string[];
  color: string;
  bgColor: string;
}

const services: Service[] = [
  {
    id: "jio-fiber",
    name: "JioFiber",
    description: "High-speed broadband for homes and businesses",
    icon: <Wifi className="w-8 h-8" />,
    features: ["Up to 1Gbps", "Unlimited Data", "OTT Bundle", "24/7 Support"],
    color: "#0080D9",
    bgColor: "bg-blue-100",
  },
  {
    id: "jio-sim",
    name: "Jio SIM",
    description: "Prepaid & Postpaid mobile plans with 5G connectivity",
    icon: <Smartphone className="w-8 h-8" />,
    features: ["5G Ready", "Instant Activation", "Multiple Plans", "Best Rates"],
    color: "#005AAC",
    bgColor: "bg-blue-50",
  },
  {
    id: "jio-airfiber",
    name: "JioAirFiber",
    description: "5G wireless broadband without installation hassle",
    icon: <Radio className="w-8 h-8" />,
    features: ["5G Speed", "No Wiring", "Plug & Play", "Affordable"],
    color: "#00A8FF",
    bgColor: "bg-cyan-50",
  },
  {
    id: "customer-support",
    name: "24/7 Customer Support",
    description: "Dedicated support for all your Jio service needs",
    icon: <Headphones className="w-8 h-8" />,
    features: ["Quick Resolution", "Expert Assistance", "Technical Help", "Billing Support"],
    color: "#00D9FF",
    bgColor: "bg-cyan-100",
  },
];

const PHONE_NUMBER = "+917006285994";
const EMAIL = "axiscommunication@gmail.com";
const WHATSAPP_MESSAGE = "Hi! I'm interested in Jio services. Can you help me?";

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  const [scrolled, setScrolled] = useState(false);
  const [visibleServices, setVisibleServices] = useState<Set<string>>(new Set());
  const [, navigate] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      // Trigger service card animations on scroll
      const cards = document.querySelectorAll("[data-service-card]");
      cards.forEach((card) => {
        const rect = card.getBoundingClientRect();
        if (rect.top < window.innerHeight * 0.8) {
          const id = card.getAttribute("data-service-id");
          if (id) {
            setVisibleServices((prev) => new Set(prev).add(id));
          }
        }
      });
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleWhatsApp = () => {
    const message = encodeURIComponent(WHATSAPP_MESSAGE);
    window.open(`https://wa.me/${PHONE_NUMBER.replace(/\D/g, "")}?text=${message}`, "_blank");
  };

  const handlePhone = () => {
    window.location.href = `tel:${PHONE_NUMBER}`;
  };

  const handleEmail = () => {
    window.location.href = `mailto:${EMAIL}?subject=Jio Services Inquiry`;
  };

  const handleCatalog = () => {
    navigate("/catalog");
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white/90 backdrop-blur-xl shadow-sm border-b border-border"
            : "bg-transparent"
        }`}
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-logo-icon-AC6huavmCyooy7Bbp4uJAH.webp"
              alt="Jio Logo"
              className="w-10 h-10"
            />
            <div>
              <span className={`font-display font-bold text-lg block ${scrolled ? "text-foreground" : "text-foreground"}`}>
                Axis Communication
              </span>
              <span className="text-xs text-muted-foreground">Jio Services & Support - J&K</span>
            </div>
          </div>
          <nav className="hidden md:flex gap-8">
            <button onClick={() => scrollToSection("services")} className="text-sm font-medium hover:text-primary transition-colors">
              Services
            </button>
            <button onClick={() => scrollToSection("why-us")} className="text-sm font-medium hover:text-primary transition-colors">
              Why Us
            </button>
            <button onClick={() => scrollToSection("contact")} className="text-sm font-medium hover:text-primary transition-colors">
              Contact
            </button>
          </nav>
          <Button onClick={handleWhatsApp} className="bg-primary hover:bg-primary/90 text-primary-foreground">
            Get Support
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663761390615/9ijYL3Xi9ps9ZoZLmodTSL/jio-hero-background-m3SG5LH5j3vSWW7ywaiVkb.webp"
            alt="Hero Background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/80 to-transparent" />
        </div>

        {/* Hero Content */}
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 mb-6 bg-accent/10 px-4 py-2 rounded-full border border-accent/20">
              <Zap className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">Connectivity at the speed of Jio</span>
            </div>

            <h1 className="font-display text-5xl md:text-6xl font-bold mb-4 text-foreground leading-tight">
              Your Trusted Jio Partner
            </h1>
            <p className="text-sm font-semibold text-primary mb-4">Axis Communication • Srinagar, J&K</p>

            <p className="text-lg text-muted-foreground mb-8 max-w-xl leading-relaxed">
              Get premium JioFiber connectivity and expert customer support. We're here to help you stay connected with fast, reliable internet and dedicated assistance.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                onClick={handleCatalog}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              >
                Order JioFiber
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button
                size="lg"
                onClick={() => scrollToSection("services")}
                variant="outline"
                className="border-2 border-foreground/20 hover:bg-foreground/5"
              >
                Explore Services
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32 bg-secondary/30 relative">
        <div className="container mx-auto px-4">
          <div className="mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-4 text-foreground">
              Our Services
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Complete Jio connectivity solutions with expert support and customer care.
            </p>
          </div>

          {/* Service Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {services.map((service, index) => (
              <Card
                key={service.id}
                data-service-card
                data-service-id={service.id}
                className={`group relative overflow-hidden transition-all duration-500 ${
                  visibleServices.has(service.id)
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                } hover:shadow-xl hover:-translate-y-1`}
              >
                {/* Gradient Background */}
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300"
                  style={{ backgroundColor: service.color }}
                />

                {/* Content */}
                <div className="relative p-8">
                  <div
                    className="w-14 h-14 rounded-lg flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110"
                    style={{ backgroundColor: service.color, color: "white" }}
                  >
                    {service.icon}
                  </div>

                  <h3 className="font-display text-2xl font-bold mb-2 text-foreground">
                    {service.name}
                  </h3>
                  <p className="text-muted-foreground mb-6">{service.description}</p>

                  {/* Features */}
                  <div className="space-y-3 mb-8">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-3">
                        <div
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: service.color }}
                        />
                        <span className="text-sm font-medium text-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Button
                    onClick={handleWhatsApp}
                    variant="ghost"
                    className="text-primary hover:text-primary/80 p-0 h-auto font-semibold"
                  >
                    Learn More
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {/* Why Choose Us */}
          <div id="why-us" className="bg-white rounded-xl p-8 md:p-12 border border-border">
            <h3 className="font-display text-3xl font-bold mb-8 text-foreground">
              Why Choose Axis Communication?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Clock className="w-8 h-8 text-primary" />,
                  title: "24/7 Support",
                  description: "Always available to help with your Jio service needs and technical issues",
                },
                {
                  icon: <CheckCircle className="w-8 h-8 text-primary" />,
                  title: "Expert Assistance",
                  description: "Experienced team with deep knowledge of all Jio products and services",
                },
                {
                  icon: <Zap className="w-8 h-8 text-primary" />,
                  title: "Quick Resolution",
                  description: "Fast and efficient solutions to get you back online quickly",
                },
              ].map((item, idx) => (
                <div key={idx} className="text-center">
                  <div className="flex justify-center mb-4">
                    {item.icon}
                  </div>
                  <h4 className="font-display font-bold text-lg mb-2 text-foreground">
                    {item.title}
                  </h4>
                  <p className="text-muted-foreground">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 md:py-32 bg-white border-t border-border">
        <div className="container mx-auto px-4">
          <h2 className="font-display text-4xl md:text-5xl font-bold mb-4 text-foreground">
            Get in Touch
          </h2>
          <p className="text-lg text-muted-foreground mb-12 max-w-2xl">
            Have questions about JioFiber or need support? Contact us today and our team will assist you.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* Address Card */}
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg mb-2 text-foreground">Office Address</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Illahi Bagh<br />
                    Srinagar, Jammu & Kashmir<br />
                    India
                  </p>
                </div>
              </div>
            </Card>

            {/* Email Card */}
            <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer" onClick={handleEmail}>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg mb-2 text-foreground">Email</h3>
                  <a href={`mailto:${EMAIL}`} className="text-primary hover:text-primary/80 transition-colors break-all">
                    {EMAIL}
                  </a>
                </div>
              </div>
            </Card>

            {/* Phone Card */}
            <Card className="p-8 hover:shadow-lg transition-shadow cursor-pointer" onClick={handlePhone}>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-display font-bold text-lg mb-2 text-foreground">Phone</h3>
                  <a href={`tel:${PHONE_NUMBER}`} className="text-primary hover:text-primary/80 transition-colors text-lg font-semibold">
                    {PHONE_NUMBER}
                  </a>
                </div>
              </div>
            </Card>
          </div>

          <div className="bg-secondary/50 rounded-xl p-8 text-center">
            <p className="text-muted-foreground mb-4">
              Available for inquiries Monday to Saturday, 9 AM - 6 PM IST
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button onClick={handleWhatsApp} className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold">
                WhatsApp Us
              </Button>
              <Button onClick={handlePhone} variant="outline" className="border-2 border-primary text-primary hover:bg-primary/10">
                Call Now
              </Button>
              <Button onClick={handleEmail} variant="outline" className="border-2 border-primary text-primary hover:bg-primary/10">
                Email Us
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-primary to-primary/80 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/10 rounded-full -mr-48 -mt-48" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-accent/5 rounded-full -ml-32 -mb-32" />

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-5xl font-bold mb-6 text-primary-foreground">
              Ready to Get Connected?
            </h2>
            <p className="text-lg text-primary-foreground/90 mb-8">
              Experience fast, reliable JioFiber connectivity with expert support from Axis Communication.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={handleCatalog}
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
              >
                Order Now
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button
                size="lg"
                onClick={handleWhatsApp}
                variant="outline"
                className="border-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10"
              >
                Contact Support
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-primary-foreground py-12 md:py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-display font-bold mb-4">Axis Communication</h4>
              <p className="text-sm text-primary-foreground/70">
                Your trusted Jio services provider and customer support partner in Srinagar, J&K.
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Services</h5>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li><button onClick={() => scrollToSection("services")} className="hover:text-primary-foreground transition">JioFiber</button></li>
                <li><button onClick={() => scrollToSection("services")} className="hover:text-primary-foreground transition">Jio SIM</button></li>
                <li><button onClick={() => scrollToSection("services")} className="hover:text-primary-foreground transition">JioAirFiber</button></li>
                <li><button onClick={() => scrollToSection("services")} className="hover:text-primary-foreground transition">Customer Support</button></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li><button onClick={() => scrollToSection("contact")} className="hover:text-primary-foreground transition">Help Center</button></li>
                <li><button onClick={() => scrollToSection("contact")} className="hover:text-primary-foreground transition">Contact Us</button></li>
                <li><button onClick={handleCatalog} className="hover:text-primary-foreground transition">Catalog</button></li>
                <li><button onClick={() => scrollToSection("services")} className="hover:text-primary-foreground transition">Service Status</button></li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4">Legal</h5>
              <ul className="space-y-2 text-sm text-primary-foreground/70">
                <li><a href="#" className="hover:text-primary-foreground transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition">Terms & Conditions</a></li>
                <li><a href="#" className="hover:text-primary-foreground transition">Disclaimer</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-primary-foreground/20 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-primary-foreground/70">
            <p>&copy; 2026 Axis Communication. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <button onClick={handleWhatsApp} className="hover:text-primary-foreground transition">WhatsApp</button>
              <button onClick={handlePhone} className="hover:text-primary-foreground transition">Call</button>
              <button onClick={handleEmail} className="hover:text-primary-foreground transition">Email</button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
